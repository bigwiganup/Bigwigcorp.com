# **Simple Parking Management System in CodeIgniter 3 Framework**

### **Recommended PHP Version >= 7.4**


==============================================================================================
## **Origianl Version Information**
- **Developed by:** Shubham Kr Ghosh
- **Download From:** [https://codeastro.com/simple-parking-management-system-in-php-codeigniter-with-source-code/](https://codeastro.com)
==============================================================================================
## **Modified Version Information**
- **Modified by:** oretnom23
- **Download From:** [https://sourcecodester.com/php-codeigniter-simple-parking-management-system-source-code/](https://sourcecodester.com)
==============================================================================================


==============================================================================================
## **Admin Access**
- **Username:** admin
- **Password:** admin123
==============================================================================================